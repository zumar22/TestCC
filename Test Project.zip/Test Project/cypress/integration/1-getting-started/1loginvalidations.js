/// <reference types="cypress" />
import Login from '../PageObjectModel/base_context'
import data from '../data.json'

describe('Login', function(){
  //Given: When URL and a valid user details are available
  //When: the user details are entered and the Login button is clicked 
  //Then: the login is successful
    const login = new Login()
    beforeEach(() => {
   
      
    })
    it('Sign in', function(){
        cy.visit('/')
        login.login(data.username,data.pasword)
        
    })

    it('click on data entry', function(){

      cy.contains('Test Graphing Model')
      .click({force:true})
      cy.contains('Test Deal Entry')
      .click({force:true})
    
      //login.dataentry().trigger("mouseover")
      
  })
})

