/// <reference types="cypress" />
import Graphmodel from '../PageObjectModel/GraphingModel'
import Login from '../PageObjectModel/base_context'
import data from '../data.json'

describe('graph model page validations', function(){
  //Given: When the graph page model is loaded
  //When: all the elements exist and are selected with right data 
  //Then: a new deal is created successfully.
  const graphmodel = new Graphmodel()
  const login = new Login()

     //Test to validate the create new deal functionality
    it('create new deal', function(){
      cy.visit('/')
      login.login(data.username,data.pasword)
      graphmodel.deal()
      //graphmodel.name().contains('Deal 6') //This is not working since the element is not complelety developed
      graphmodel.point().type('LZ')
      
      graphmodel.graph().should('exist')
      graphmodel.graph_table().should('exist')

      graphmodel.newbutton().click()
    })

    //Test to validate the save functionality
  it('save new deal', function(){
    graphmodel.savebutton().click()
    
  })
})

