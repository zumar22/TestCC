class graphingmodel{
    deal(){
        return cy.get('#selDealName').select('118')
    }
    name(){
        return cy.get('#txtDealName')
    }
    point(){
        return cy.get('#selSettlementPoint')
    }
    zone(){
        return cy.get('#selSettlementPoint')
    }

    graph(){
        return cy.get('#graphs_right')
    }

    graph_table(){
        return cy.get('#graphs_left')
    }

    newbutton(){
       return cy.get('.btn-danger')
    }

    savebutton(){
        return cy.get('.btn-info')
    }
    elements()
    {
        this.deal().exists()
        this.name().exists()
    }

    
}
export default graphingmodel