class login{
    email(){
        return cy.get('input[type="email"]')
    }
    password(){
        return cy.get('input[type="password"]')
    }
    signInButton(){
        return cy.get('.btn-primary').contains('Login')
    }

    dataentry(){
        return cy.get('.active > [href=""]')
    }

    graphingmodel(){
        return cy.get('.active > [href="/testing_stuff"]')
    }
    login(username,password)
    {
        this.email().type('combocurve_user@combocurve.com')
        this.password().type('combocurve_12')
        this.signInButton().click()
    }

    
}
export default login