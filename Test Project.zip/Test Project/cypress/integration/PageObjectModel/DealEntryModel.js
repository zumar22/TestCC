class dealentry{
    selectdeal(){
        return cy.get('input[id="selDealName"]')
    }
    
}
export default dealentry